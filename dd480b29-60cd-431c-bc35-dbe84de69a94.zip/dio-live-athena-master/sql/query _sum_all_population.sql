select
	sum(population)
from "population"."population";
