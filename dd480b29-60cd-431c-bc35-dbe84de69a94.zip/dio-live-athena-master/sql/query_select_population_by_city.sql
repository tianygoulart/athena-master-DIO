select city, population
from "population"."population"
where city='Foz do Iguaçu';
